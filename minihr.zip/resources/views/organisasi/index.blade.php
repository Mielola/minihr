@extends('adminlte::page')

@section('title', 'Organisasi')

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <h1>Organisasi</h1>

        <ol class="breadcrumb float-sm-right m-0">
            <li class="breadcrumb-item active">
                <a href="{{ route('dashboard') }}">Dasbor</a>
            </li>
            <li class="breadcrumb-item active">Organisasi</li>
        </ol>
    </div>
@stop

@section('content')
    <div class="card">
        <div class="card-header">Data</div>
        <div class="card-body">
            <div id="tree"></div>
        </div>
    </div>
@stop

@section('css')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/orgchart/2.1.9/css/jquery.orgchart.min.css" />
    <style>
        .orgchart {
            background: none !important;
        }

        .orgchart .node {
            height: auto !important;
            min-height: 80px;
            padding: 6px 4px;
        }

        .orgchart .node .title {
            height: auto !important;
            background-color: #858796;
            padding: 6px 4px;
            line-height: 1.2em;
            white-space: normal !important;
        }

        .orgchart .node .content {
            height: auto !important;
            padding: 10px 4px !important;
            white-space: normal !important;
        }

        .node-avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            object-fit: cover;
            display: block;
            margin: 0 auto 6px auto;
        }

        .node-name {
            color: #007bff;
            font-weight: 600;
            font-size: 13px;
            margin-top: 4px;
            line-height: 1.2em;
            white-space: normal;
        }
    </style>
@endsection

@section('js')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/orgchart/2.1.9/js/jquery.orgchart.min.js"></script>

    <script>
        const rawNodes = @json($nodes);
        const map = {};
        const tree = [];

        rawNodes.forEach(n => {
            map[n.id] = {
                ...n,
                children: []
            };
        });

        rawNodes.forEach(n => {
            if (n.pid) {
                map[n.pid].children.push(map[n.id]);
            } else {
                tree.push(map[n.id]);
            }
        });

        const dataSource = tree[0];

        $('#tree').orgchart({
            data: dataSource,
            nodeContent: 'title',
            pan: true,
            zoom: true,

            createNode: function($node, data) {
                const content = $node.children('.content');
                const title = $node.children('.title');

                title.text(data.name);
                content.empty();

                const img = $('<img>', {
                    src: data.avatar,
                    class: 'node-avatar'
                });

                const name = $('<div>', {
                    class: 'node-name',
                    text: data.title
                });

                content.append(img).append(name);
            }
        });
    </script>
@endsection
