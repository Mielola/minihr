@extends('adminlte::page')

@section('title', 'Aktivitas')

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <h1>Aktivitas</h1>

        <ol class="breadcrumb float-sm-right m-0">
            <li class="breadcrumb-item">
                <a href="{{ route('dashboard') }}">Dasbor</a>
            </li>
            <li class="breadcrumb-item active">Aktivitas</li>
        </ol>
    </div>
@stop

@section('content')

    <div class="card">
        <div class="card-header">Data</div>

        <div class="card-body">

            {{-- TOP BUTTON + EXPORT --}}
            <div class="d-flex justify-content-between mb-3">
                <a href="{{ route('aktivitas.create') }}" class="btn btn-primary btn-sm">Tambah</a>
            </div>

            {{-- BULAN & TAHUN --}}
            <div class="mb-3">
                <label class="font-weight-bold">Bulan & Tahun</label>

                <form action="{{ route('aktivitas.index') }}">
                    <div class="input-group">
                        <input type="month" name="bulan_tahun" value="{{ $monthYear }}"
                            class="form-control form-control-sm">

                        <div class="input-group-append">
                            <button class="btn btn-secondary btn-sm">
                                <i class="fas fa-calendar"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <div class="mb-3 d-flex justify-content-end gap-2">
                <button class="btn btn-success btn-sm mr-1">Cetak Spreadsheet</button>
                <a href="{{ route('aktivitas.pdf', ['bulan_tahun' => $monthYear]) }}" class="btn btn-danger btn-sm">
                    Cetak PDF
                </a>
            </div>

            {{-- SHOW ENTRIES + SEARCH --}}
            <div class="d-flex justify-content-between align-items-center mb-2">

                <div>
                    <label class="m-0">
                        Tampilkan
                        <select id="entries" class="custom-select custom-select-sm form-control form-control-sm"
                            style="width:70px;">
                            <option value="10" {{ request()->per_page == 10 ? 'selected' : '' }}>10</option>
                            <option value="25" {{ request()->per_page == 25 ? 'selected' : '' }}>25</option>
                            <option value="50" {{ request()->per_page == 50 ? 'selected' : '' }}>50</option>
                            <option value="100" {{ request()->per_page == 100 ? 'selected' : '' }}>100</option>
                        </select>
                        entri
                    </label>
                </div>

                <div class="d-flex align-items-center gap-2">
                    <label class="m-0">
                        Cari :
                    </label>
                    <input id="search" type="search" class="form-control form-control-sm" placeholder="Cari..."
                        style="width:150px;">
                </div>
            </div>

            {{-- TABLE --}}
            <table id="activityTable" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th style="width: 80px;">Opsi</th>
                        <th>Mulai</th>
                        <th>Selesai</th>
                        <th style="width: 800px;">Keterangan</th>
                    </tr>
                </thead>

                <tbody>
                    @forelse ($data as $a)
                        <tr>
                            <td>
                                <form action="{{ route('aktivitas.destroy', $a->id) }}" method="POST" class="d-inline">
                                    @csrf
                                    @method('DELETE')
                                    <button onclick="return confirm('Hapus data?')"
                                        class="btn btn-danger btn-sm">Hapus</button>
                                </form>
                            </td>
                            <td>{{ date('d-m-Y H:i', strtotime($a->mulai)) }}</td>
                            <td>{{ $a->selesai ? date('d-m-Y H:i', strtotime($a->selesai)) : '-' }}</td>
                            <td>{{ $a->keterangan }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="4" class="text-center text-muted">Tidak ada data</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>

            <div class="mt-2">
                {{ $data->appends(request()->query())->links() }}
            </div>

        </div>
    </div>

@stop

@section('js')
    <script>
        // Search local table
        document.getElementById('search').addEventListener('keyup', function() {
            let value = this.value.toLowerCase();
            let rows = document.querySelectorAll("#activityTable tbody tr");

            rows.forEach(row => {
                row.style.display = row.innerText.toLowerCase().includes(value) ? "" : "none";
            });
        });

        // Entries (pagination per page)
        document.getElementById('entries').addEventListener('change', function() {
            let perPage = this.value;
            let url = new URL(window.location.href);
            url.searchParams.set('per_page', perPage);
            window.location.href = url.toString();
        });
    </script>
@endsection
