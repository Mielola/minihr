@extends('adminlte::page')

@section('title', 'Tambah Aktivitas')

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <h1>Tambah Aktivitas</h1>

        <ol class="breadcrumb float-sm-right m-0">
            <li class="breadcrumb-item">
                <a href="{{ route('dashboard') }}">Dasbor</a>
            </li>
            <li class="breadcrumb-item">
                <a href="{{ route('aktivitas.index') }}">Aktivitas</a>
            </li>
            <li class="breadcrumb-item active">Tambah Aktivitas</li>
        </ol>
    </div>
@stop

@section('content')

    <div class="card">
        <div class="card-header">Form</div>

        <div class="card-body">

            <form action="{{ route('aktivitas.store') }}" method="POST">
                @csrf

                {{-- Tanggal --}}
                <div class="form-group">
                    <label>Tanggal</label>
                    <div class="input-group">
                        <input type="date" name="tanggal" value="{{ date('Y-m-d', strtotime($absen->masuk)) }}"
                            class="form-control" required>
                        <div class="input-group-append">
                            <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                        </div>
                    </div>
                </div>

                {{-- Mulai & Selesai --}}
                <div class="row">
                    <div class="col-md-6">
                        <label>Mulai</label>
                        <div class="input-group">
                            <input type="datetime-local" name="mulai" class="form-control"
                                min="{{ $absen->masuk ? date('Y-m-d\TH:i', strtotime($absen->masuk)) : '' }}"
                                max="{{ $absen->pulang ? date('Y-m-d\TH:i', strtotime($absen->pulang)) : '' }}" required>
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label>Selesai</label>
                        <div class="input-group">
                            <input type="datetime-local" name="selesai" class="form-control"
                                min="{{ $absen->masuk ? date('Y-m-d\TH:i', strtotime($absen->masuk)) : '' }}"
                                max="{{ $absen->pulang ? date('Y-m-d\TH:i', strtotime($absen->pulang)) : '' }}">
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Keterangan --}}
                <div class="form-group mt-3">
                    <label>Keterangan</label>
                    <input type="text" name="keterangan" class="form-control">
                </div>

                <div class="text-right mt-3">
                    <a href="{{ route('aktivitas.index') }}" class="btn btn-secondary">Batal</a>
                    <button class="btn btn-primary">Simpan</button>
                </div>

            </form>
        </div>
    </div>

@stop
