@extends('layouts.auth')

@section('content')
    <div class="login-page" style="min-height: 100vh;">
        <div class="d-flex flex-column justify-content-center align-items-center h-100">

            {{-- Logo + Title --}}
            <div class="text-center mb-4">
                <div class="d-flex align-items-center justify-content-center">
                    <i class="fas fa-university fa-3x text-dark"></i>
                    <h2 class="font-weight-bold text-xl text-dark ml-3 mb-0">Mini HR</h2>
                </div>
            </div>


            {{-- Card Login --}}
            <div class="card shadow" style="width: 360px;">
                <div class="card-body">

                    <h6 class="text-center text-muted mb-4">Masuk Untuk Memulai</h6>

                    {{-- Form login --}}
                    <form method="POST" action="{{ route('login') }}">
                        @csrf

                        {{-- Email / Username --}}
                        <div class="input-group mb-3">
                            <input type="text" name="username" class="form-control" placeholder="Username" required
                                autofocus>
                            <div class="input-group-append">
                                <span class="input-group-text">
                                    <i class="fas fa-user"></i>
                                </span>
                            </div>
                        </div>

                        {{-- Error --}}
                        @error('username')
                            <p class="text-danger text-sm mb-2">{{ $message }}</p>
                        @enderror

                        {{-- Password --}}
                        <div class="input-group mb-3">
                            <input type="password" name="password" class="form-control" placeholder="Password" required>
                            <div class="input-group-append">
                                <span class="input-group-text">
                                    <i class="fas fa-lock"></i>
                                </span>
                            </div>
                        </div>

                        @error('password')
                            <p class="text-danger text-sm mb-2">{{ $message }}</p>
                        @enderror

                        {{-- Button Login --}}
                        <button type="submit" class="btn btn-primary btn-block btn-lg mt-3">
                            Login
                        </button>
                    </form>

                </div>
            </div>

        </div>
    </div>
@endsection