@extends('adminlte::page')

@section('title', 'Absensi')

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <h1>Absensi</h1>

        <ol class="breadcrumb float-sm-right m-0">
            <li class="breadcrumb-item active">
                <a href="{{ route('dashboard') }}">Dasbor</a>
            </li>
            <li class="breadcrumb-item active">Absensi</li>
        </ol>
    </div>
@stop

@section('content')

    <div class="card">
        <div class="card-header">
            <strong>Data</strong>
        </div>

        <div class="card-body">

            {{-- TOP BAR --}}
            <div class="d-flex justify-content-between align-items-center mb-3">
                {{-- Show entries --}}
                <div>
                    <label>
                        Tampilkan
                        <select class="custom-select custom-select-sm w-auto"
                            onchange="window.location.href='?per_page=' + this.value">
                            <option value="10" {{ request('per_page') == 10 ? 'selected' : '' }}>10</option>
                            <option value="25" {{ request('per_page') == 25 ? 'selected' : '' }}>25</option>
                            <option value="50" {{ request('per_page') == 50 ? 'selected' : '' }}>50</option>
                        </select>
                        entri
                    </label>
                </div>

                {{-- Search --}}
                <form method="GET" action="{{ route('absensi.index') }}">
                    <div class="input-group">
                        <input type="text" name="q" value="{{ request('q') }}"
                            class="form-control form-control-sm" placeholder="Cari ...">
                        <div class="input-group-append">
                            <button class="btn btn-secondary btn-sm">Cari</button>
                        </div>
                    </div>
                </form>
            </div>

            {{-- TABLE --}}
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Masuk</th>
                        <th>Pulang</th>
                    </tr>
                </thead>

                <tbody>
                    @forelse ($absensi as $a)
                        <tr>
                            <td>{{ date('d-m-Y H:i:s', strtotime($a->masuk)) }}</td>
                            <td>
                                {{ $a->pulang ? date('d-m-Y H:i:s', strtotime($a->pulang)) : '-' }}
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="2" class="text-center text-muted">Tidak ada data</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>

            {{-- PAGINATION --}}
            <div class="mt-3">
                {{ $absensi->links() }}
            </div>

        </div>
    </div>

@stop
