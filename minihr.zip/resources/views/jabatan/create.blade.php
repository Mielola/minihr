@extends('adminlte::page')

@section('title', 'Tambah')

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <h1>Tambah Jabatan</h1>

        <ol class="breadcrumb float-sm-right m-0">
            <li class="breadcrumb-item active">
                <a href="{{ route('dashboard') }}">Dasbor</a>
            </li>
            <li class="breadcrumb-item">
                <a href="{{ route('jabatan.index') }}">Jabatan</a>
            </li>
            <li class="breadcrumb-item active">Tambah Jabatan</li>
        </ol>
    </div>
@stop

@section('content')
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Form</h3>
        </div>

        <form action="{{ route('jabatan.store') }}" method="POST">
            @csrf
            <div class="card-body">

                {{-- Nama Jabatan --}}
                <div class="form-group">
                    <label for="nama">Nama Jabatan</label>
                    <input type="text" name="nama" id="nama"
                        class="form-control @error('nama') is-invalid @enderror"
                        placeholder="Contoh: Chief Technology Officer" required>

                    @error('nama')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>

                {{-- Keterangan --}}
                <div class="form-group">
                    <label for="keterangan">Keterangan</label>
                    <textarea name="keterangan" id="keterangan" rows="3"
                        class="form-control @error('keterangan') is-invalid @enderror" placeholder="Deskripsi atau tugas jabatan..."></textarea>

                    @error('keterangan')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>

            </div>

            <div class="card-footer d-flex justify-content-end gap-2">
                <a href="{{ route('jabatan.index') }}" class="btn btn-secondary mr-2">Batal</a>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>

        </form>
    </div>
@endsection
