@extends('adminlte::page')

@section('title', 'Edit')

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <h1>Edit Jabatan</h1>

        <ol class="breadcrumb float-sm-right m-0">
            <li class="breadcrumb-item active">
                <a href="{{ route('dashboard') }}">Dasbor</a>
            </li>
            <li class="breadcrumb-item">
                <a href="{{ route('jabatan.index') }}">Jabatan</a>
            </li>
            <li class="breadcrumb-item active">Edit Jabatan</li>
        </ol>
    </div>
@stop

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dasbor</a></li>
    <li class="breadcrumb-item"><a href="{{ route('jabatan.index') }}">Jabatan</a></li>
    <li class="breadcrumb-item active">Edit</li>
@endsection

@section('content')

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Form Edit Jabatan</h3>
        </div>

        <form action="{{ route('jabatan.update', $jabatan->id) }}" method="POST">
            @csrf
            @method('PUT')

            <div class="card-body">

                {{-- Nama Jabatan --}}
                <div class="form-group">
                    <label for="nama">Nama Jabatan</label>
                    <input type="text" name="nama" id="nama"
                        class="form-control @error('nama') is-invalid @enderror" value="{{ old('nama', $jabatan->nama) }}"
                        required>

                    @error('nama')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>

                {{-- Keterangan --}}
                <div class="form-group">
                    <label for="keterangan">Keterangan</label>
                    <textarea name="keterangan" id="keterangan" rows="3"
                        class="form-control @error('keterangan') is-invalid @enderror" placeholder="Deskripsi jabatan...">{{ old('keterangan', $jabatan->keterangan) }}</textarea>

                    @error('keterangan')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>

            </div>

            <div class="card-footer d-flex justify-content-end">
                <a href="{{ route('jabatan.index') }}" class="btn btn-secondary mr-2">Batal</a>
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            </div>
        </form>
    </div>

@endsection
