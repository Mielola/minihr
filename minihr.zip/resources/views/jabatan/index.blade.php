@extends('adminlte::page')

@section('title', 'Jabatan')

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <h1>Jabatan</h1>

        <ol class="breadcrumb float-sm-right m-0">
            <li class="breadcrumb-item active">
                <a href="{{ route('dashboard') }}">Dasbor</a>
            </li>
            <li class="breadcrumb-item active">Jabatan</li>
        </ol>
    </div>
@stop

@section('content')

    @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Data Jabatan</h3>
        </div>

        <div class="card-body">
            <div class="card-tools mb-3">
                <a href="{{ route('jabatan.create') }}" class="btn btn-primary btn-sm">Tambah</a>
                <a href="#" class="btn btn-success btn-sm">Cetak Spreadsheet</a>
            </div>

            <table id="jabatanTable" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th style="width: 140px;">Opsi</th>
                        <th>Nama</th>
                        <th>Keterangan</th>
                        <th style="width:150px;">Tanggal Buat</th>
                    </tr>
                </thead>

                <tbody>
                    @foreach ($data as $item)
                        <tr>
                            <td>
                                <a href="{{ route('jabatan.edit', $item->id) }}" class="btn btn-warning btn-sm">Ubah</a>

                                <form action="{{ route('jabatan.destroy', $item->id) }}" method="POST" class="d-inline">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-danger btn-sm" onclick="return confirm('Hapus data?')">
                                        Hapus
                                    </button>
                                </form>
                            </td>

                            <td>{{ $item->nama }}</td>
                            <td>{{ $item->keterangan }}</td>
                            <td>{{ $item->created_at->format('d-m-Y H:i') }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>

        </div>

    </div>

@stop

@section('css')
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap4.min.css">
@stop

@section('js')
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap4.min.js"></script>

    <script>
        $(function() {
            $('#jabatanTable').DataTable({
                responsive: true,
                ordering: true,
                paging: true,
                lengthChange: true,
                searching: true,
                autoWidth: false,
                language: {
                    lengthMenu: "Tampilkan _MENU_ entri",
                    search: "Cari:",
                    paginate: {
                        next: "Selanjutnya",
                        previous: "Sebelumnya"
                    },
                    info: "Menampilkan _START_ sampai _END_ dari _TOTAL_ entri"
                }
            });
        });
    </script>
@stop
