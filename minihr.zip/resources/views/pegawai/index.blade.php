@extends('adminlte::page')

@section('title', 'Pegawai')

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <h1>Pegawai</h1>

        <ol class="breadcrumb float-sm-right m-0">
            <li class="breadcrumb-item active">
                <a href="{{ route('dashboard') }}">Dasbor</a>
            </li>
            <li class="breadcrumb-item active">Pegawai</li>
        </ol>
    </div>
@stop

@section('content')

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3 class="card-title">Data</h3>
        </div>

        <div class="card-body">

            {{-- BUTTON --}}
            <div class="mb-3">
                <a href="{{ route('pegawai.create') }}" class="btn btn-primary btn-sm">Tambah</a>
                <a href="#" class="btn btn-success btn-sm">Cetak Spreadsheet</a>
            </div>

            {{-- FILTER --}}
            <form method="GET" class="d-flex justify-content-between mb-3">
                <div>
                    <label class="d-flex align-items-center">
                        <span class="mr-2">Tampilkan</span>
                        <select name="per_page" class="form-control form-control-sm" onchange="this.form.submit()"
                            style="width: 70px;">
                            <option {{ request()->per_page == 10 ? 'selected' : '' }}>10</option>
                            <option {{ request()->per_page == 25 ? 'selected' : '' }}>25</option>
                            <option {{ request()->per_page == 50 ? 'selected' : '' }}>50</option>
                        </select>
                        <span class="ml-2">entri</span>
                    </label>
                </div>

                <div>
                    <label class="d-flex align-items-center">
                        <span class="mr-2">Cari:</span>
                        <input type="text" name="search" class="form-control form-control-sm"
                            value="{{ request()->search }}" placeholder="Cari...">
                    </label>
                </div>
            </form>

            {{-- TABLE --}}
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Opsi</th>
                        <th>NIP</th>
                        <th>Nama</th>
                        <th>Jabatan</th>
                        <th>Tanggal Buat</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($data as $item)
                        <tr>
                            <td width="190">
                                <a href="{{ route('pegawai.show', $item->id) }}" class="btn btn-info btn-sm">Detail</a>
                                <a href="{{ route('pegawai.edit', $item->id) }}" class="btn btn-warning btn-sm"
                                    style="color: white;">Ubah</a>

                                <form action="{{ route('pegawai.destroy', $item->id) }}" method="POST" class="d-inline">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-danger btn-sm"
                                        onclick="return confirm('Hapus data?')">Hapus</button>
                                </form>
                            </td>

                            <td>{{ $item->nip }}</td>
                            <td>{{ $item->nama }}</td>
                            <td>{{ $item->jabatan->nama ?? '-' }}</td>
                            <td>{{ $item->created_at->format('d-m-Y H:i') }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>

            {{-- PAGINATION --}}
            <div class="d-flex justify-content-between mt-3">
                <span class="text-muted">
                    Menampilkan {{ $data->firstItem() }} sampai {{ $data->lastItem() }} dari {{ $data->total() }} entri
                </span>
                {{ $data->appends(request()->all())->links('pagination::bootstrap-4') }}
            </div>

        </div>
    </div>

@stop
