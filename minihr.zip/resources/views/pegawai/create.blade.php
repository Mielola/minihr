@extends('adminlte::page')

@section('title', 'Tambah Pegawai')

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <h1>Tambah Pegawai</h1>

        <ol class="breadcrumb float-sm-right m-0">
            <li class="breadcrumb-item active">
                <a href="{{ route('dashboard') }}">Dasbor</a>
            </li>
            <li class="breadcrumb-item active">
                <a href="{{ route('pegawai.index') }}">Pegawai</a>
            </li>
            <li class="breadcrumb-item active">Tambah Pegawai</li>
        </ol>
    </div>
@stop

@section('content')

    <div class="card">
        <div class="card-body">

            <h5 class="mb-3">Form</h5>

            <form action="{{ route('pegawai.store') }}" method="POST" enctype="multipart/form-data">
                @csrf

                {{-- NAMA --}}
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" name="nama" class="form-control" placeholder="Nama pegawai" required>
                </div>

                {{-- TEMPAT LAHIR + TANGGAL LAHIR + JENIS KELAMIN --}}
                <div class="row">

                    <div class="col-md-4">
                        <label>Tempat Lahir</label>
                        <input type="text" name="tempat_lahir" class="form-control" placeholder="Bandung" required>
                    </div>

                    <div class="col-md-4">
                        <label>Tanggal Lahir</label>
                        <div class="input-group">
                            <input type="date" name="tanggal_lahir" class="form-control" required>
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <label>Jenis Kelamin</label>
                        <select name="jenis_kelamin" class="form-control" required>
                            <option value="">Pilih</option>
                            <option value="Laki-laki">Laki-laki</option>
                            <option value="Perempuan">Perempuan</option>
                        </select>
                    </div>

                </div>

                {{-- TMT --}}
                <div class="mt-3">
                    <label>TMT (Terhitung Mulai Tanggal)</label>
                    <div class="input-group">
                        <input type="date" name="tmt" class="form-control" required>
                        <div class="input-group-append">
                            <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                        </div>
                    </div>
                </div>

                {{-- JABATAN --}}
                <div class="mt-3">
                    <label>Jabatan</label>
                    <select name="jabatan_id" class="form-control" required>
                        <option value="">Pilih Jabatan</option>

                        @foreach ($jabatan as $j)
                            <option value="{{ $j->id }}">{{ $j->nama }}</option>
                        @endforeach

                    </select>
                </div>

                {{-- NIP --}}
                <div class="mt-3">
                    <label>NIP <small class="text-muted">(Terisi otomatis oleh Tanggal Lahir, Jenis Kelamin dan
                            TMT)</small></label>
                    <input type="text" name="nip" id="nip" class="form-control bg-light" readonly>
                </div>

                {{-- FOTO --}}
                <div class="mt-3">
                    <label>Foto <small>(Ekstensi JPG, JPEG dan PNG Maksimal 1MB)</small></label>
                    <input type="file" name="foto" class="form-control-file">
                </div>

                <div class="mt-4 text-right">
                    <a href="{{ route('pegawai.index') }}" class="btn btn-secondary">Batal</a>
                    <button class="btn btn-primary">Simpan</button>
                </div>

            </form>
        </div>
    </div>

@stop

@section('js')
    <script>
        function generateNIP() {
            let tgl = document.querySelector("input[name='tanggal_lahir']").value;
            let tmt = document.querySelector("input[name='tmt']").value;
            let genderValue = document.querySelector("select[name='jenis_kelamin']").value;

            if (!tgl || !tmt || !genderValue) {
                return;
            }

            let formatDate = (d) => d.replaceAll('-', '');
            let tglLahir = formatDate(tgl);
            let tmtFormatted = formatDate(tmt);
            let gender = genderValue === "Perempuan" ? "1" : "0";
            let randomPlaceholder = "000";

            let nip = `${tglLahir}${tmtFormatted}${gender}${randomPlaceholder}`;

            document.getElementById('nip').value = nip;
        }

        document.querySelector("input[name='tanggal_lahir']").addEventListener("change", generateNIP);
        document.querySelector("select[name='jenis_kelamin']").addEventListener("change", generateNIP);
        document.querySelector("input[name='tmt']").addEventListener("change", generateNIP);
    </script>

@stop
