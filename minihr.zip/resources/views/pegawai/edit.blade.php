@extends('adminlte::page')

@section('title', 'Edit Pegawai')

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <h1>Edit Pegawai</h1>

        <ol class="breadcrumb float-sm-right m-0">
            <li class="breadcrumb-item active">
                <a href="{{ route('dashboard') }}">Dasbor</a>
            </li>
            <li class="breadcrumb-item active">
                <a href="{{ route('pegawai.index') }}">Pegawai</a>
            </li>
            <li class="breadcrumb-item active">Edit Pegawai</li>
        </ol>
    </div>
@stop

@section('content')

    <div class="card">
        <div class="card-body">

            <h5 class="mb-3">Form</h5>

            <form action="{{ route('pegawai.update', $pegawai->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                {{-- NAMA --}}
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" name="nama" class="form-control" value="{{ $pegawai->nama }}" required>
                </div>

                {{-- TEMPAT LAHIR + TANGGAL LAHIR + JENIS KELAMIN --}}
                <div class="row">

                    <div class="col-md-4">
                        <label>Tempat Lahir</label>
                        <input type="text" name="tempat_lahir" class="form-control" value="{{ $pegawai->tempat_lahir }}"
                            required>
                    </div>

                    <div class="col-md-4">
                        <label>Tanggal Lahir</label>
                        <div class="input-group">
                            <input type="date" name="tanggal_lahir" class="form-control"
                                value="{{ $pegawai->tanggal_lahir }}" required>
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <label>Jenis Kelamin</label>
                        <select name="jenis_kelamin" class="form-control" required>
                            <option value="Laki-laki" {{ $pegawai->jenis_kelamin == 'Laki-laki' ? 'selected' : '' }}>
                                Laki-laki</option>
                            <option value="Perempuan" {{ $pegawai->jenis_kelamin == 'Perempuan' ? 'selected' : '' }}>
                                Perempuan</option>
                        </select>
                    </div>

                </div>

                {{-- TMT --}}
                <div class="mt-3">
                    <label>TMT (Terhitung Mulai Tanggal)</label>
                    <div class="input-group">
                        <input type="date" name="tmt" class="form-control" value="{{ $pegawai->tmt }}" required>
                        <div class="input-group-append">
                            <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                        </div>
                    </div>
                </div>

                {{-- JABATAN --}}
                <div class="mt-3">
                    <label>Jabatan</label>
                    <select name="jabatan_id" class="form-control" required>
                        @foreach ($jabatan as $j)
                            <option value="{{ $j->id }}" {{ $pegawai->jabatan_id == $j->id ? 'selected' : '' }}>
                                {{ $j->nama }}
                            </option>
                        @endforeach
                    </select>
                </div>

                {{-- NIP --}}
                <div class="mt-3">
                    <label>NIP <small class="text-muted">(Terisi otomatis oleh Tanggal Lahir, Jenis Kelamin dan
                            TMT)</small></label>
                    <input type="text" name="nip" id="nip" class="form-control bg-light"
                        value="{{ $pegawai->nip }}" readonly>
                </div>

                {{-- FOTO --}}
                <div class="mt-3">
                    <label>Foto <small>(Ekstensi JPG, JPEG dan PNG Maksimal 1MB)</small></label>
                    <input type="file" name="foto" class="form-control-file">

                    @if ($pegawai->foto)
                        <div class="mt-2">
                            <img src="{{ asset('storage/' . $pegawai->foto) }}" width="90" class="img-thumbnail">
                            <p class="text-muted small">(Foto saat ini)</p>
                        </div>
                    @endif
                </div>

                <div class="mt-4 text-right">
                    <a href="{{ route('pegawai.index') }}" class="btn btn-secondary">Batal</a>
                    <button class="btn btn-primary">Simpan</button>
                </div>

            </form>
        </div>
    </div>

@stop

@section('js')
    <script>
        function generateNIP() {
            let tglLahir = document.querySelector("input[name='tanggal_lahir']").value.replaceAll('-', '');
            let gender = document.querySelector("select[name='jenis_kelamin']").value === "Perempuan" ? "2" : "1";
            let tmt = document.querySelector("input[name='tmt']").value.replaceAll('-', '');

            if (tglLahir && gender && tmt) {
                document.getElementById('nip').value = tglLahir + gender + tmt + "001";
            }
        }

        document.querySelector("input[name='tanggal_lahir']").addEventListener("change", generateNIP);
        document.querySelector("select[name='jenis_kelamin']").addEventListener("change", generateNIP);
        document.querySelector("input[name='tmt']").addEventListener("change", generateNIP);
    </script>
@stop
