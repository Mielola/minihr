@extends('adminlte::page')

@section('title', 'Dasbor')

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <h1>Dasbor</h1>

        <ol class="breadcrumb float-sm-right m-0">
            <li class="breadcrumb-item active">Dasbor</li>
        </ol>
    </div>
@stop

@section('content')

    <div class="row">

        {{-- CARD PEGAWAI --}}
        <div class="col-lg-6 col-md-6 col-sm-12">
            <div class="small-box bg-info">
                <div class="inner">
                    <h3>{{ $jumlahPegawai ?? 0 }}</h3>
                    <p>Pegawai</p>
                </div>
                <div class="icon">
                    <i class="fas fa-users"></i>
                </div>
            </div>
        </div>

        {{-- CARD AKTIVITAS --}}
        <div class="col-lg-6 col-md-6 col-sm-12">
            <div class="small-box bg-success">
                <div class="inner">
                    <h3>{{ $jumlahAktivitas ?? 0 }}</h3>
                    <p>Aktivitas</p>
                </div>
                <div class="icon">
                    <i class="fas fa-list"></i>
                </div>
            </div>
        </div>

    </div>

@stop
