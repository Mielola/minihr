<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Aktivitas Pegawai</title>

    <style>
        body {
            font-family: "DejaVu Sans", sans-serif;
            font-size: 12px;
            margin: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        .header-table td {
            padding: 3px 0;
        }

        .main-table th,
        .main-table td {
            border: 1px solid #000;
            padding: 6px 5px;
            vertical-align: top;
        }

        .main-table th {
            text-align: center;
            background: #f2f2f2;
        }

        .footer-date {
            margin-top: 40px;
            font-size: 11px;
        }
    </style>
</head>

<body>

    <table class="header-table">
        <tr>
            <td width="80">NIP</td>
            <td>: <?php echo e($user->nip ?? '-'); ?></td>
        </tr>
        <tr>
            <td>Nama</td>
            <td>: <?php echo e($user->nama ?? $user->name); ?></td>
        </tr>
        <tr>
            <td>Jabatan</td>
            <td>: <?php echo e($user->jabatan->nama ?? '-'); ?></td>
        </tr>
    </table>

    <br>

    <table class="main-table">
        <thead>
            <tr>
                <th style="width: 20%">Tanggal</th>
                <th style="width: 20%">Jam</th>
                <th style="width: 60%">Keterangan</th>
            </tr>
        </thead>

        <tbody>

            <?php
                $grouped = $aktivitas->groupBy(function($row){
                    return \Carbon\Carbon::parse($row->mulai)->format('Y-m-d');
                });
            ?>

            <?php $__empty_1 = true; $__currentLoopData = $grouped; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tanggal => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $rowspan = count($items);
                    $tanggalFormatted = \Carbon\Carbon::parse($tanggal)->translatedFormat('d F Y');
                ?>

                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <?php if($index === 0): ?>
                            <td rowspan="<?php echo e($rowspan); ?>">
                                <?php echo e($tanggalFormatted); ?>

                            </td>
                        <?php endif; ?>

                        <td>
                            <?php echo e(\Carbon\Carbon::parse($row->mulai)->format('H:i')); ?>

                            –
                            <?php echo e($row->selesai ? \Carbon\Carbon::parse($row->selesai)->format('H:i') : '-'); ?>

                        </td>

                        <td>
                            <?php echo e($row->keterangan); ?>

                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" style="text-align:center;">Tidak ada aktivitas</td>
                </tr>
            <?php endif; ?>

        </tbody>
    </table>

    <div class="footer-date">
        <?php echo e(\Carbon\Carbon::now()->translatedFormat('d F Y H:i:s')); ?>

    </div>

</body>

</html><?php /**PATH C:\laragon\www\mini-hr\resources\views/aktivitas/pdf.blade.php ENDPATH**/ ?>