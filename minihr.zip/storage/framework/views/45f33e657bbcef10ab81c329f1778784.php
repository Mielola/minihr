

<?php $__env->startSection('title', 'Tambah Aktivitas'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between align-items-center">
        <h1>Tambah Aktivitas</h1>

        <ol class="breadcrumb float-sm-right m-0">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>">Dasbor</a>
            </li>
            <li class="breadcrumb-item active">
                <a href="<?php echo e(route('aktivitas.index')); ?>">Aktivitas</a>
            </li>
            <li class="breadcrumb-item active">Tambah Aktivitas</li>
        </ol>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">Form</div>

        <div class="card-body">

            <form action="<?php echo e(route('aktivitas.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                
                <div class="form-group">
                    <label>Tanggal</label>
                    <div class="input-group">
                        <input type="date" name="tanggal" value="<?php echo e(date('Y-m-d', strtotime($absen->masuk))); ?>"
                            class="form-control" required>
                        <div class="input-group-append">
                            <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                        </div>
                    </div>
                </div>

                
                <div class="row">
                    <div class="col-md-6">
                        <label>Mulai</label>
                        <div class="input-group">
                            <input type="datetime-local" name="mulai" class="form-control"
                                min="<?php echo e($absen->masuk ? date('Y-m-d\TH:i', strtotime($absen->masuk)) : ''); ?>"
                                max="<?php echo e($absen->pulang ? date('Y-m-d\TH:i', strtotime($absen->pulang)) : ''); ?>" required>
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label>Selesai</label>
                        <div class="input-group">
                            <input type="datetime-local" name="selesai" class="form-control"
                                min="<?php echo e($absen->masuk ? date('Y-m-d\TH:i', strtotime($absen->masuk)) : ''); ?>"
                                max="<?php echo e($absen->pulang ? date('Y-m-d\TH:i', strtotime($absen->pulang)) : ''); ?>">
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="form-group mt-3">
                    <label>Keterangan</label>
                    <input type="text" name="keterangan" class="form-control">
                </div>

                <div class="text-right mt-3">
                    <a href="<?php echo e(route('aktivitas.index')); ?>" class="btn btn-secondary">Batal</a>
                    <button class="btn btn-primary">Simpan</button>
                </div>

            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\mini-hr\resources\views/aktivitas/create.blade.php ENDPATH**/ ?>