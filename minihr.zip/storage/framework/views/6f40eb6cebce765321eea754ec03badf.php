<?php $__env->startSection('title', 'Dasbor'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between align-items-center">
        <h1>Dasbor</h1>

        <ol class="breadcrumb float-sm-right m-0">
            <li class="breadcrumb-item active">Dasbor</li>
        </ol>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">

        
        <div class="col-lg-6 col-md-6 col-sm-12">
            <div class="small-box bg-info">
                <div class="inner">
                    <h3><?php echo e($jumlahPegawai ?? 0); ?></h3>
                    <p>Pegawai</p>
                </div>
                <div class="icon">
                    <i class="fas fa-users"></i>
                </div>
            </div>
        </div>

        
        <div class="col-lg-6 col-md-6 col-sm-12">
            <div class="small-box bg-success">
                <div class="inner">
                    <h3><?php echo e($jumlahAktivitas ?? 0); ?></h3>
                    <p>Aktivitas</p>
                </div>
                <div class="icon">
                    <i class="fas fa-list"></i>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\mini-hr\resources\views/dashboard/admin/dashboard.blade.php ENDPATH**/ ?>