

<?php $__env->startSection('classes_body', 'layout-fixed'); ?>

<?php $__env->startSection('title', 'Dasbor'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between align-items-center">
        <h1>Dasbor</h1>

        <ol class="breadcrumb float-sm-right m-0">
            <li class="breadcrumb-item active">Dasbor</li>
        </ol>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

    <style>
        .map-box {
            height: 200px !important;
            width: 100% !important;
            border-radius: 6px;
            overflow: hidden;
        }

        .leaflet-container {
            width: 100% !important;
            height: 200px !important;
        }

        #donutChart {
            max-width: 240px;
            max-height: 240px;
            margin: auto;
        }

        .timeline {
            list-style: none !important;
            padding-left: 0 !important;
            position: relative;
        }

        .timeline:before {
            content: '';
            position: absolute;
            top: 0;
            bottom: 0;
            width: 3px;
            background: #c5c5c5;
            left: 35px;
        }

        .timeline>li {
            position: relative;
        }

        .timeline>li>i {
            position: absolute;
            left: 17px;
            width: 36px;
            height: 36px;
            background: #6c757d;
            color: white;
            border-radius: 50%;
            line-height: 36px;
            text-align: center;
            z-index: 10;
        }

        .timeline-item {
            margin-left: 70px;
            background: #fff;
            border: 1px solid #e1e1e1;
            border-radius: 6px;
            padding: 15px;
        }

        .timeline-status-divider {
            border-bottom: 1px solid #ddd;
            margin-top: 5px;
            margin-bottom: 10px;
        }

        .timeline-end {
            display: none !important;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    
    <div class="card mb-4">
        <div class="card-header">Absensi Terakhir</div>

        <div class="card-body">
            <div class="row">

                <div class="col-md-6 mb-3">
                    <h6>Masuk</h6>

                    <?php if($absensi): ?>
                        <p><?php echo e(date('d F Y H:i:s', strtotime($absensi->masuk))); ?></p>
                        <div id="mapMasuk" class="map-box"></div>
                    <?php else: ?>
                        <p>-</p>
                    <?php endif; ?>
                </div>

                <div class="col-md-6 mb-3">
                    <h6>Pulang</h6>

                    <?php if($absensi && $absensi->pulang): ?>
                        <p><?php echo e(date('d F Y H:i:s', strtotime($absensi->pulang))); ?></p>
                        <div id="mapPulang" class="map-box"></div>
                    <?php else: ?>
                        <p>-</p>
                    <?php endif; ?>
                </div>

            </div>

            <div class="mt-4 text-center">
                <canvas id="donutChart"></canvas>
            </div>

        </div>
    </div>


    <div class="card mb-4">
        <div class="card-header">
            <h6 class="m-0">Aktivitas Terakhir</h6>
        </div>

        <div class="card-body">

            <ul class="timeline timeline-inverse">

                <?php $__currentLoopData = $aktivitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>

                        <i class="fas fa-circle"></i>

                        <div class="timeline-item">

                            <span class="badge badge-secondary">Menunggu</span>

                            <div class="timeline-status-divider"></div>

                            <h5 class="timeline-header font-weight-bold">
                                <?php echo e(date('d-m-Y H:i', strtotime($a->mulai))); ?>

                                —
                                <?php echo e($a->selesai ? date('d-m-Y H:i', strtotime($a->selesai)) : '-'); ?>

                            </h5>

                            <?php
                                $durasi = $a->selesai ? floor((strtotime($a->selesai) - strtotime($a->mulai)) / 60) : 0;
                            ?>

                            <small><?php echo e($durasi); ?> menit</small>

                            <div class="timeline-body mt-3">
                                <?php echo e($a->keterangan); ?>

                            </div>

                        </div>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <li class="timeline-end"></li>

            </ul>
        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('js'); ?>

    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {

            // MAP MASUK
            <?php if($absensi && $absensi->lokasi_masuk): ?>
                let masuk = <?php echo $absensi->lokasi_masuk; ?>;
                let mapMasuk = L.map('mapMasuk').setView([masuk.lat, masuk.lng], 17);
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(mapMasuk);
                L.marker([masuk.lat, masuk.lng]).addTo(mapMasuk);
            <?php endif; ?>

            // MAP PULANG
            <?php if($absensi && $absensi->lokasi_pulang): ?>
                let pulang = <?php echo $absensi->lokasi_pulang; ?>;
                let mapPulang = L.map('mapPulang').setView([pulang.lat, pulang.lng], 17);
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(mapPulang);
                L.marker([pulang.lat, pulang.lng]).addTo(mapPulang);
            <?php endif; ?>

            // DONUT CHART
            new Chart(document.getElementById('donutChart'), {
                type: 'doughnut',
                data: {
                    labels: ['Menit Tersisa', 'Menit Tercapai'],
                    datasets: [{
                        data: [<?php echo e($menitTersisa); ?>, <?php echo e($menitMasuk); ?>],
                        backgroundColor: ['#d2d2d2', '#007bff'],
                    }]
                },
                options: {
                    cutout: '70%',
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });

        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\mini-hr\resources\views/dashboard/pegawai/dashboard.blade.php ENDPATH**/ ?>