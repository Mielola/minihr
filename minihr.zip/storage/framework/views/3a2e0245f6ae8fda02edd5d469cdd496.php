## Tailwind 3

- Always use Tailwind CSS v3 - verify you're using only classes supported by this version.
<?php /**PATH C:\laragon\www\mini-hr\storage\framework\views/ebdf252d948197a8ec00c88ebb497d11.blade.php ENDPATH**/ ?>