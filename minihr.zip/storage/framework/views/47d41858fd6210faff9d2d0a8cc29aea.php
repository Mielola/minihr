<?php $__env->startSection('content'); ?>
    <div class="login-page" style="min-height: 100vh;">
        <div class="d-flex flex-column justify-content-center align-items-center h-100">

            
            <div class="text-center mb-4">
                <div class="d-flex align-items-center justify-content-center">
                    <i class="fas fa-university fa-3x text-dark"></i>
                    <h2 class="font-weight-bold text-xl text-dark ml-3 mb-0">Mini HR</h2>
                </div>
            </div>


            
            <div class="card shadow" style="width: 360px;">
                <div class="card-body">

                    <h6 class="text-center text-muted mb-4">Masuk Untuk Memulai</h6>

                    
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        
                        <div class="input-group mb-3">
                            <input type="text" name="username" class="form-control" placeholder="Username" required
                                autofocus>
                            <div class="input-group-append">
                                <span class="input-group-text">
                                    <i class="fas fa-user"></i>
                                </span>
                            </div>
                        </div>

                        
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger text-sm mb-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        
                        <div class="input-group mb-3">
                            <input type="password" name="password" class="form-control" placeholder="Password" required>
                            <div class="input-group-append">
                                <span class="input-group-text">
                                    <i class="fas fa-lock"></i>
                                </span>
                            </div>
                        </div>

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger text-sm mb-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        
                        <button type="submit" class="btn btn-primary btn-block btn-lg mt-3">
                            Login
                        </button>
                    </form>

                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\mini-hr\resources\views/auth/login.blade.php ENDPATH**/ ?>