

<?php $__env->startSection('title', 'Pegawai'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between align-items-center">
        <h1>Pegawai</h1>

        <ol class="breadcrumb float-sm-right m-0">
            <li class="breadcrumb-item active">
                <a href="<?php echo e(route('dashboard')); ?>">Dasbor</a>
            </li>
            <li class="breadcrumb-item active">Pegawai</li>
        </ol>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3 class="card-title">Data</h3>
        </div>

        <div class="card-body">

            
            <div class="mb-3">
                <a href="<?php echo e(route('pegawai.create')); ?>" class="btn btn-primary btn-sm">Tambah</a>
                <a href="#" class="btn btn-success btn-sm">Cetak Spreadsheet</a>
            </div>

            
            <form method="GET" class="d-flex justify-content-between mb-3">
                <div>
                    <label class="d-flex align-items-center">
                        <span class="mr-2">Tampilkan</span>
                        <select name="per_page" class="form-control form-control-sm" onchange="this.form.submit()"
                            style="width: 70px;">
                            <option <?php echo e(request()->per_page == 10 ? 'selected' : ''); ?>>10</option>
                            <option <?php echo e(request()->per_page == 25 ? 'selected' : ''); ?>>25</option>
                            <option <?php echo e(request()->per_page == 50 ? 'selected' : ''); ?>>50</option>
                        </select>
                        <span class="ml-2">entri</span>
                    </label>
                </div>

                <div>
                    <label class="d-flex align-items-center">
                        <span class="mr-2">Cari:</span>
                        <input type="text" name="search" class="form-control form-control-sm"
                            value="<?php echo e(request()->search); ?>" placeholder="Cari...">
                    </label>
                </div>
            </form>

            
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Opsi</th>
                        <th>NIP</th>
                        <th>Nama</th>
                        <th>Jabatan</th>
                        <th>Tanggal Buat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td width="190">
                                <a href="<?php echo e(route('pegawai.show', $item->id)); ?>" class="btn btn-info btn-sm">Detail</a>
                                <a href="<?php echo e(route('pegawai.edit', $item->id)); ?>" class="btn btn-warning btn-sm"
                                    style="color: white;">Ubah</a>

                                <form action="<?php echo e(route('pegawai.destroy', $item->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger btn-sm"
                                        onclick="return confirm('Hapus data?')">Hapus</button>
                                </form>
                            </td>

                            <td><?php echo e($item->nip); ?></td>
                            <td><?php echo e($item->nama); ?></td>
                            <td><?php echo e($item->jabatan->nama ?? '-'); ?></td>
                            <td><?php echo e($item->created_at->format('d-m-Y H:i')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            
            <div class="d-flex justify-content-between mt-3">
                <span class="text-muted">
                    Menampilkan <?php echo e($data->firstItem()); ?> sampai <?php echo e($data->lastItem()); ?> dari <?php echo e($data->total()); ?> entri
                </span>
                <?php echo e($data->appends(request()->all())->links('pagination::bootstrap-4')); ?>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\mini-hr\resources\views/pegawai/index.blade.php ENDPATH**/ ?>