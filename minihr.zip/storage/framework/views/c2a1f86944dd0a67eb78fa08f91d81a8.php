

<?php $__env->startSection('title', 'Absensi'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between align-items-center">
        <h1>Absensi</h1>

        <ol class="breadcrumb float-sm-right m-0">
            <li class="breadcrumb-item active">
                <a href="<?php echo e(route('dashboard')); ?>">Dasbor</a>
            </li>
            <li class="breadcrumb-item active">Absensi</li>
        </ol>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            <strong>Data</strong>
        </div>

        <div class="card-body">

            
            <div class="d-flex justify-content-between align-items-center mb-3">
                
                <div>
                    <label>
                        Tampilkan
                        <select class="custom-select custom-select-sm w-auto"
                            onchange="window.location.href='?per_page=' + this.value">
                            <option value="10" <?php echo e(request('per_page') == 10 ? 'selected' : ''); ?>>10</option>
                            <option value="25" <?php echo e(request('per_page') == 25 ? 'selected' : ''); ?>>25</option>
                            <option value="50" <?php echo e(request('per_page') == 50 ? 'selected' : ''); ?>>50</option>
                        </select>
                        entri
                    </label>
                </div>

                
                <form method="GET" action="<?php echo e(route('absensi.index')); ?>">
                    <div class="input-group">
                        <input type="text" name="q" value="<?php echo e(request('q')); ?>"
                            class="form-control form-control-sm" placeholder="Cari ...">
                        <div class="input-group-append">
                            <button class="btn btn-secondary btn-sm">Cari</button>
                        </div>
                    </div>
                </form>
            </div>

            
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Masuk</th>
                        <th>Pulang</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $absensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(date('d-m-Y H:i:s', strtotime($a->masuk))); ?></td>
                            <td>
                                <?php echo e($a->pulang ? date('d-m-Y H:i:s', strtotime($a->pulang)) : '-'); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="2" class="text-center text-muted">Tidak ada data</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            
            <div class="mt-3">
                <?php echo e($absensi->links()); ?>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\mini-hr\resources\views/absensi/index.blade.php ENDPATH**/ ?>