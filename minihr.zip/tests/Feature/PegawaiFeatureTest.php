<?php

use App\Models\User;
use App\Models\Pegawai;
use App\Models\Jabatan;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);
uses(Tests\TestCase::class);

test('admin dapat melihat daftar pegawai', function () {
    $admin = User::factory()->create(['role' => 'admin']);

    $this->actingAs($admin)
        ->get('/pegawai')
        ->assertStatus(200)
        ->assertSee('Data');
});

test('admin dapat menambahkan pegawai', function () {
    $admin = User::factory()->create(['role' => 'admin']);
    $jabatan = Jabatan::factory()->create();

    $response = $this->actingAs($admin)->post('/pegawai', [
        'nama' => 'Budi Test',
        'tempat_lahir' => 'Bandung',
        'tanggal_lahir' => '2000-01-01',
        'jenis_kelamin' => 'Laki-laki',
        'tmt' => '2020-01-01',
        'jabatan_id' => $jabatan->id,
    ]);

    $response->assertRedirect('/pegawai');
    $this->assertDatabaseHas('pegawai', ['nama' => 'Budi Test']);
});

test('admin dapat mengupdate pegawai', function () {
    $admin = User::factory()->create(['role' => 'admin']);
    $jabatan = Jabatan::factory()->create();

    $pegawai = Pegawai::factory()->create([
        'jabatan_id' => $jabatan->id
    ]);

    $response = $this->actingAs($admin)->put("/pegawai/{$pegawai->id}", [
        'nama' => 'Nama Baru',
        'tempat_lahir' => $pegawai->tempat_lahir,
        'tanggal_lahir' => $pegawai->tanggal_lahir,
        'jenis_kelamin' => $pegawai->jenis_kelamin,
        'tmt' => $pegawai->tmt,
        'jabatan_id' => $jabatan->id,
        'nip' => $pegawai->nip,
    ]);

    $response->assertRedirect('/pegawai');
    $this->assertDatabaseHas('pegawai', ['nama' => 'Nama Baru']);
});

test('admin dapat menghapus pegawai', function () {
    $admin = User::factory()->create(['role' => 'admin']);
    $pegawai = Pegawai::factory()->create();

    $response = $this->actingAs($admin)->delete("/pegawai/{$pegawai->id}");

    $response->assertRedirect('/pegawai');
    $this->assertDatabaseMissing('pegawai', ['id' => $pegawai->id]);
});