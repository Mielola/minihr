<?php

namespace Database\Seeders;

use App\Models\Pegawai;
use App\Models\Jabatan;
use App\Models\User;
use Illuminate\Database\Seeder;

class PegawaiSeeder extends Seeder
{
    public function run(): void
    {
        // List jabatan yg sudah dibuat di JabatanSeeder
        $jabatan = Jabatan::pluck('id', 'nama')->toArray();

        // Data pegawai sesuai struktur organisasi
        $pegawaiData = [
            ["nama" => "Dutch Van Der Linde", "jabatan" => "Chief Executive Officer"],
            ["nama" => "Hosea Matthews", "jabatan" => "Chief Operating Officer"],
            ["nama" => "Arthur Morgan", "jabatan" => "Human Resource"],
            ["nama" => "Sadie Adler", "jabatan" => "Human Resource"],

            ["nama" => "Bill Williamson", "jabatan" => "Chief Technology Officer"],
            ["nama" => "Micah Bell", "jabatan" => "Backend Engineer"],
            ["nama" => "John Marston", "jabatan" => "Backend Engineer"],

            ["nama" => "Lenny Summers", "jabatan" => "Frontend Engineer"],
            ["nama" => "Charles Smith", "jabatan" => "Frontend Engineer"],
            ["nama" => "Sean MacGuire", "jabatan" => "Frontend Engineer"],

            ["nama" => "Uncle", "jabatan" => "DevOps Engineer"],

            ["nama" => "Susan Grimshaw", "jabatan" => "Chief Financial Officer"],
            ["nama" => "Simon Pearson", "jabatan" => "Accountant"],
            ["nama" => "Reverend Swanson", "jabatan" => "Accountant"],

            ["nama" => "Mary-Beth Gaskill", "jabatan" => "Financial Analyst"],
            ["nama" => "Abigail Roberts", "jabatan" => "Internal Auditor"],
            ["nama" => "Jack Marston", "jabatan" => "Internal Auditor"],

            // ["nama" => "—", "jabatan" => "Tax Accountant"],

            ["nama" => "Leopold Strauss", "jabatan" => "Chief Marketing Officer"],
            ["nama" => "Josiah Trelawny", "jabatan" => "Marketing"],
            ["nama" => "Molly O'Shea", "jabatan" => "Marketing"],
            ["nama" => "Tilly Jackson", "jabatan" => "Social Media Specialist"],
        ];

        foreach ($pegawaiData as $item) {

            // Generate NIP otomatis (dummy)
            $nip = rand(1000000000000000, 9999999999999999);

            $username = strtolower(str_replace(' ', '', $item['nama']));
            $user = User::create([
                'name'     => $item['nama'],
                'username' => $username,
                'password' => $nip,
                'role'     => 'pegawai',
            ]);

            Pegawai::create([
                'nama' => $item['nama'],
                'tempat_lahir' => 'Bandung',
                'tanggal_lahir' => '1990-01-01',
                'jenis_kelamin' => 'Laki-laki',
                'tmt' => '2020-01-01',
                'nip' => $nip,
                'jabatan_id' => $jabatan[$item['jabatan']],
                'foto' => null,
                'user_id' => $user->id,
            ]);
        }
    }
}
