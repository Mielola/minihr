<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::create([
        //     'username' => 'admin1',
        //     'name' => 'Admin User1',
        //     'role' => 'admin',
        //     'password' => 'password',
        // ]);

        $this->call([
            // JabatanSeeder::class,
            // PegawaiSeeder::class,
            // AbsensiSeeder::class,
        ]);
    }
}
