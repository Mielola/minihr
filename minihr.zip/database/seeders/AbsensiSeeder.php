<?php

namespace Database\Seeders;

use App\Models\Absensi;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class AbsensiSeeder extends Seeder
{
    public function run(): void
    {
        Absensi::create([
            'user_id' => 3,
            'masuk' => Carbon::parse('2025-11-27 09:15:00'),
            'pulang' => Carbon::parse('2025-11-27 20:45:00'),
            'lokasi_masuk' => json_encode(['lat' => -6.914744, 'lng' => 107.609810]),
            'lokasi_pulang' => json_encode(['lat' => -6.915500, 'lng' => 107.610000]),
        ]);
    }
}