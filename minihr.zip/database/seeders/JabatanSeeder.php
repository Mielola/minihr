<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Jabatan;

class JabatanSeeder extends Seeder
{
    public function run(): void
    {
        $data = [
            ['nama' => 'Chief Executive Officer', 'position' => '1'],

            ['nama' => 'Chief Operating Officer', 'position' => '1.1'],
            ['nama' => 'Human Resource',          'position' => '1.1.1'],

            ['nama' => 'Chief Technology Officer', 'position' => '1.2'],
            ['nama' => 'Backend Engineer',         'position' => '1.2.1'],
            ['nama' => 'Frontend Engineer',        'position' => '1.2.2'],
            ['nama' => 'DevOps Engineer',          'position' => '1.2.3'],

            ['nama' => 'Chief Financial Officer',  'position' => '1.3'],
            ['nama' => 'Accountant',               'position' => '1.3.1'],
            ['nama' => 'Financial Analyst',        'position' => '1.3.2'],
            ['nama' => 'Internal Auditor',         'position' => '1.3.3'],

            ['nama' => 'Chief Marketing Officer',  'position' => '1.4'],
            ['nama' => 'Marketing',                'position' => '1.4.1'],
            ['nama' => 'Social Media Specialist',  'position' => '1.4.2'],
        ];

        foreach ($data as $item) {
            Jabatan::create($item);
        }
    }
}
