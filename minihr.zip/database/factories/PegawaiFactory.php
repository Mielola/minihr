<?php

namespace Database\Factories;

use App\Models\Jabatan;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class PegawaiFactory extends Factory
{
    public function definition()
    {
        return [
            'nama' => $this->faker->name(),
            'tempat_lahir' => $this->faker->city(),
            'tanggal_lahir' => $this->faker->date(),
            'jenis_kelamin' => $this->faker->randomElement(['Laki-laki', 'Perempuan']),
            'tmt' => $this->faker->date(),
            'jabatan_id' => Jabatan::factory(),
            'user_id' => User::factory(),
            'nip' => $this->faker->unique()->numerify('################'),
        ];
    }
}