<?php

namespace App\Providers;

use Illuminate\Support\Facades\Gate;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        Gate::before(function ($user, $ability) {
            // Hubungkan permission adminlte dengan config/auth
            $permissions = config('auth.permissions');

            if (isset($permissions[$ability])) {
                return $permissions[$ability]($user);
            }

            return null;
        });
    }
}