<?php

namespace App\Http\Controllers;

use App\Models\Absensi;
use App\Models\Aktivitas;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AktivitasController extends Controller
{
    public function index(Request $request)
    {
        $monthYear = $request->bulan_tahun ?? date('Y-m');
        [$year, $month] = explode('-', $monthYear);

        $query = Aktivitas::with('user')
            ->whereYear('mulai', $year)
            ->whereMonth('mulai', $month);

        if (Auth::user()->role === 'pegawai') {
            $query->where('user_id', Auth::id());
        }

        $data = $query->orderBy('mulai', 'asc')->paginate(10);
        return view('aktivitas.index', compact('data', 'monthYear'));
    }

    public function create()
    {
        $absen = Absensi::where('user_id', Auth::id())
            ->whereDate('masuk', date('Y-m-d'))
            ->first();

        if (!$absen) {
            return redirect()->route('aktivitas.index')
                ->with('error', 'Anda belum melakukan absensi masuk hari ini.');
        }

        $absen->masuk = date('Y-m-d\TH:i', strtotime($absen->masuk));
        $absen->pulang = $absen->pulang ? date('Y-m-d\TH:i', strtotime($absen->pulang)) : null;

        return view('aktivitas.create', compact('absen'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'mulai' => 'required|date',
            'selesai' => 'nullable|date|after:mulai',
            'keterangan' => 'required|string',
        ]);

        $absen = Absensi::where('user_id', Auth::id())
            ->whereDate('masuk', date('Y-m-d', strtotime($request->mulai)))
            ->first();

        if (!$absen) {
            return back()->with('error', 'Anda belum absen pada hari ini.');
        }

        $mulai = Carbon::parse($request->mulai);
        $selesai = $request->selesai ? Carbon::parse($request->selesai) : null;
        $masuk = Carbon::parse($absen->masuk);
        $pulang = $absen->pulang ? Carbon::parse($absen->pulang) : null;

        if ($mulai->lt($masuk) || ($pulang && $mulai->gt($pulang))) {
            return back()->with('error', 'Jam mulai harus sesuai rentang absen masuk dan pulang.');
        }

        if ($selesai) {
            if ($selesai->lt($masuk) || ($pulang && $selesai->gt($pulang))) {
                return back()->with('error', 'Jam selesai harus sesuai rentang absen masuk dan pulang.');
            }
        }

        Aktivitas::create([
            'user_id' => Auth::id(),
            'tanggal' => $mulai->toDateString(),
            'mulai' => $mulai,
            'selesai' => $selesai,
            'keterangan' => $request->keterangan,
        ]);

        return redirect()->route('aktivitas.index')->with('success', 'Aktivitas berhasil ditambahkan.');
    }


    public function destroy(Aktivitas $aktivitas)
    {
        $aktivitas->delete();
        return redirect()->route('aktivitas.index')->with('success', 'Aktivitas berhasil dihapus.');
    }

    public function exportPdf(Request $request)
    {
        $monthYear = $request->bulan_tahun ?? date('Y-m');
        $parsed = explode('-', $monthYear);

        $user = Auth::user();
        $pegawai = $user->pegawai;

        if ($pegawai) {
            $user->jabatan = $pegawai->jabatan;
            $user->nip = $pegawai->nip;
        }

        $aktivitas = Aktivitas::where('user_id', $user->id)
            ->whereYear('mulai', $parsed[0])
            ->whereMonth('mulai', $parsed[1])
            ->orderBy('mulai')
            ->get();

        $pdf = Pdf::loadView('aktivitas.pdf', [
            'user' => $user,
            'aktivitas' => $aktivitas,
            'monthYear' => $monthYear
        ]);

        return $pdf->stream('aktivitas-' . $monthYear . '.pdf');
    }
}
