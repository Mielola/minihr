<?php

namespace App\Http\Controllers;

use App\Models\Absensi;
use App\Models\Aktivitas;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        // Ambil absensi terakhir
        $absensi = Absensi::where('user_id', $user->id)
            ->orderBy('masuk', 'desc')
            ->first();

        // Ambil aktivitas terakhir 5 item
        $aktivitas = Aktivitas::where('user_id', $user->id)
            ->orderBy('mulai', 'desc')
            ->take(5)
            ->get();

        // Hitung ringkasan kehadiran (contoh 480 menit = 8 jam)
        $waktuKerja = 480;

        $menitMasuk = 0;

        if ($absensi && $absensi->masuk && $absensi->pulang) {
            $menitMasuk = floor((strtotime($absensi->pulang) - strtotime($absensi->masuk)) / 60);
        }

        return view('dashboard.pegawai.dashboard', [
            'user'      => $user,
            'absensi'   => $absensi,
            'aktivitas' => $aktivitas,
            'menitMasuk' => $menitMasuk,
            'menitTersisa' => max(0, $waktuKerja - $menitMasuk)
        ]);
    }

    public function adminDashboard()
    {
        $jumlahPegawai = User::where('role', 'pegawai')->count();
        $jumlahAktivitas = Aktivitas::count();

        return view('dashboard.admin.dashboard', compact(
            'jumlahPegawai',
            'jumlahAktivitas'
        ));
    }
}
