<?php

namespace App\Http\Controllers;

use App\Models\Pegawai;
use App\Models\Jabatan;

class OrganisasiController extends Controller
{
    public function index()
    {
        $jabatan = Jabatan::orderByRaw('LENGTH(position), position')->get();
        $nodes = [];

        foreach ($jabatan as $j) {
            $pegawai = Pegawai::where('jabatan_id', $j->id)->first();
            $parentPos = null;
            if (str_contains($j->position, '.')) {
                $parentPos = substr($j->position, 0, strrpos($j->position, '.'));
            }

            $parent = null;
            if ($parentPos) {
                $parent = Jabatan::where('position', $parentPos)->first();
            }

            $nodes[] = [
                'name'  => $j->nama,
                'title' => $pegawai->nama ?? '-',
                'avatar' => "https://api.dicebear.com/7.x/adventurer/svg?seed="
                    . urlencode($pegawai->nama ?? $j->nama),
                'children' => [],
                'id' => $j->position,
                'pid' => $parent?->position
            ];
        }

        return view('organisasi.index', compact('nodes'));
    }
}
