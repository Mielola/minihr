<?php

namespace App\Http\Controllers;

use App\Models\Absensi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AbsensiController extends Controller
{
    public function index(Request $request)
    {
        $perPage = $request->per_page ?? 10;

        $absensi = Absensi::where('user_id', Auth::id())
            ->orderBy('masuk', 'desc')
            ->paginate($perPage);

        return view('absensi.index', compact('absensi'));
    }
}
