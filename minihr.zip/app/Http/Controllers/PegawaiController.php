<?php

namespace App\Http\Controllers;

use App\Models\Pegawai;
use App\Models\Jabatan;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class PegawaiController extends Controller
{
    public function index(Request $request)
    {
        $perPage = $request->per_page ?? 10;
        $search  = $request->search;

        $data = Pegawai::with('jabatan')
            ->when($search, function ($query) use ($search) {
                $query->where('nama', 'like', "%$search%")
                    ->orWhere('nip', 'like', "%$search%")
                    ->orWhereHas('jabatan', function ($q) use ($search) {
                        $q->where('nama', 'like', "%$search%");
                    });
            })
            ->orderBy('created_at', 'desc')
            ->paginate($perPage);

        return view('pegawai.index', compact('data'));
    }

    public function create()
    {
        $jabatan = Jabatan::all();
        return view('pegawai.create', compact('jabatan'));
    }


    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required',
            'tempat_lahir' => 'required',
            'tanggal_lahir' => 'required|date',
            'jenis_kelamin' => 'required',
            'tmt' => 'required|date',
            'jabatan_id' => 'required',
            'foto' => 'nullable|image|max:1024'
        ]);

        $nip = $this->generateNip(
            $request->tanggal_lahir,
            $request->tmt,
            $request->jenis_kelamin
        );
        $user = User::create([
            'username' => strtolower(str_replace(' ', '', $request->nama)),
            'name'     => $request->nama,
            'password' => $nip,
            'role'     => 'pegawai',
        ]);


        $data = $request->except('foto');
        $data['user_id'] = $user->id;
        $data['nip'] = $nip;

        if ($request->hasFile('foto')) {
            $data['foto'] = $request->file('foto')->store('pegawai', 'public');
        }

        Pegawai::create($data);

        return redirect()->route('pegawai.index')->with('success', 'Pegawai & Akun User berhasil dibuat.');
    }

    public function show($id)
    {
        return view('pegawai.show');
    }

    public function edit($id)
    {
        $pegawai = Pegawai::findOrFail($id);
        $jabatan = Jabatan::all();
        return view('pegawai.edit', compact('pegawai', 'jabatan'));
    }

    public function update(Request $request, Pegawai $pegawai)
    {
        $request->validate([
            'nama' => 'required',
            'tempat_lahir' => 'required',
            'tanggal_lahir' => 'required|date',
            'jenis_kelamin' => 'required',
            'tmt' => 'required|date',
            'jabatan_id' => 'required',
            'nip' => "required|unique:pegawai,nip,$pegawai->id",
            'foto' => 'nullable|image|max:1024'
        ]);

        $data = $request->except('foto');

        if ($request->hasFile('foto')) {
            if ($pegawai->foto) {
                Storage::disk('public')->delete($pegawai->foto);
            }
            $data['foto'] = $request->file('foto')->store('pegawai', 'public');
        }

        $pegawai->update($data);

        return redirect()->route('pegawai.index')->with('success', 'Pegawai berhasil diupdate.');
    }

    public function destroy(Pegawai $pegawai)
    {
        if ($pegawai->foto) {
            Storage::disk('public')->delete($pegawai->foto);
        }

        $pegawai->delete();

        return redirect()->route('pegawai.index')->with('success', 'Pegawai berhasil dihapus.');
    }

    private function generateNip($tanggal_lahir, $tmt, $jenis_kelamin)
    {
        $tglLahir = date('Ymd', strtotime($tanggal_lahir));
        $tmtFormat = date('Ymd', strtotime($tmt));
        $jk = $jenis_kelamin === 'Perempuan' ? 1 : 0;

        $rand = str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT);

        return $tglLahir . $tmtFormat . $jk . $rand;
    }
}
