<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Absensi extends Model
{
    protected $fillable = [
        'user_id',
        'masuk',
        'pulang',
        'lokasi_masuk',
        'lokasi_pulang',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}