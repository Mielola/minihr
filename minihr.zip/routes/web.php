<?php

use App\Http\Controllers\AbsensiController;
use App\Http\Controllers\AktivitasController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\JabatanController;
use App\Http\Controllers\OrganisasiController;
use App\Http\Controllers\PegawaiController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('auth.login');
});

Route::middleware('auth', 'role:pegawai')->group(function () {
    // Profile
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::middleware(['auth', 'role:admin'])->group(function () {

    // Jabatan
    Route::get('jabatan', [JabatanController::class, 'index'])->name('jabatan.index');
    Route::get('jabatan/create', [JabatanController::class, 'create'])->name('jabatan.create');
    Route::post('jabatan', [JabatanController::class, 'store'])->name('jabatan.store');
    Route::get('jabatan/{id}/edit', [JabatanController::class, 'edit'])->name('jabatan.edit');
    Route::put('jabatan/{jabatan}', [JabatanController::class, 'update'])->name('jabatan.update');
    Route::delete('jabatan/{jabatan}', [JabatanController::class, 'destroy'])->name('jabatan.destroy');

    // Pegawai
    Route::get('pegawai', [PegawaiController::class, 'index'])->name('pegawai.index');
    Route::get('pegawai/create', [PegawaiController::class, 'create'])->name('pegawai.create');
    Route::get('pegawai/{id}/show', [PegawaiController::class, 'show'])->name('pegawai.show');
    Route::post('pegawai', [PegawaiController::class, 'store'])->name('pegawai.store');
    Route::get('pegawai/{id}/edit', [PegawaiController::class, 'edit'])->name('pegawai.edit');
    Route::put('pegawai/{pegawai}', [PegawaiController::class, 'update'])->name('pegawai.update');
    Route::delete('pegawai/{pegawai}', [PegawaiController::class, 'destroy'])->name('pegawai.destroy');

    // Organisasi
    Route::get('organisasi', [OrganisasiController::class, 'index'])->name('organisasi.index');
});

Route::middleware('auth')->group(function () {
    // Aktivitas
    Route::get('aktivitas', [AktivitasController::class, 'index'])->name('aktivitas.index');
    Route::get('aktivitas/create', [AktivitasController::class, 'create'])->name('aktivitas.create');
    Route::delete('aktivitas/{aktivitas}', [AktivitasController::class, 'destroy'])->name('aktivitas.destroy');
    Route::post('aktivitas', [AktivitasController::class, 'store'])->name('aktivitas.store');

    // Absensi
    Route::get('absensi', [AbsensiController::class, 'index'])->name('absensi.index');
    Route::get('aktivitas/pdf', [AktivitasController::class, 'exportPdf'])->name('aktivitas.pdf');
});

Route::middleware('auth')->get('/dashboard', function () {

    if (Auth::user()->role === 'admin') {
        return app(DashboardController::class)->adminDashboard();
    }

    return app(DashboardController::class)->index();
})->name('dashboard');



require __DIR__ . '/auth.php';
